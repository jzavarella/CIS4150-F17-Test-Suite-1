
I've thrown together some code for this demo.  It loads everything
into a giant array, and then uses bsearch() to find the right value.

I ran it on a few test examples, and you can see that I have given
you a "testit" script that shows that it works.

The boss is very concerned that this works absolutely perfectly,
however, so please hammer on it and make up a good test suite.  I've
tried typing in a few sample values, and it all seemed to look fine
to me though, so I think that it should be ok. (The boss is really
insisting on a solid test suite, though.)

Thanks,
Sam

